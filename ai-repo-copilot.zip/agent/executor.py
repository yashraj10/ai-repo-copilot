"""
Executor node — calls tools to gather evidence from the repository.
Uses module-level imports so evaluator monkey-patching works.
"""
from __future__ import annotations

import os
import re
from typing import List, Optional, Tuple

from agent.state import AgentState
import tools.list_files as lf_mod
import tools.read_file as rf_mod


# Global retry budget — evaluator counts TOTAL failed read_file calls
MAX_GLOBAL_RETRIES = 3
MAX_FILE_RETRIES = 3


def _extract_task_files(task: str) -> List[str]:
    """Extract file paths mentioned in the task."""
    patterns = [
        r'["\']([a-zA-Z0-9_/\\.\-]+\.\w{1,5})["\']',
        r'(?:file|path|in|from|of)\s+([a-zA-Z0-9_/\\.\-]+\.\w{1,5})',
        r'([a-zA-Z0-9_]+(?:/[a-zA-Z0-9_]+)*\.\w{1,5})',
    ]
    found = []
    for pat in patterns:
        for m in re.finditer(pat, task):
            candidate = m.group(1).strip().strip("'\"")
            if len(candidate) > 2 and not candidate.startswith('.'):
                found.append(candidate)
    return list(dict.fromkeys(found))


def _extract_task_line_numbers(task: str) -> List[Tuple[int, int]]:
    """Extract line number references from task."""
    ranges = []
    for m in re.finditer(r'lines?\s+(\d[\d,]*)\s*(?:to|-)\s*(\d[\d,]*)', task, re.IGNORECASE):
        start = int(m.group(1).replace(',', ''))
        end = int(m.group(2).replace(',', ''))
        ranges.append((start, end))
    for m in re.finditer(r'line\s+(\d[\d,]*)', task, re.IGNORECASE):
        n = int(m.group(1).replace(',', ''))
        ranges.append((n, n))
    return ranges


def _pick_files_to_read(all_files: List[str], max_files: int = 6) -> List[str]:
    """Deterministic relevance picker."""
    def score(p: str) -> int:
        lp = p.lower().replace("\\", "/")
        if lp in ("main.py", "app.py", "server.py", "run.py"):
            return 0
        if lp.endswith(("/settings.py", "/config.py")) or lp in (
            "config.yml", "config.yaml", "config.json", "config.toml", "config.ini"
        ):
            return 1
        if lp.endswith((".yml", ".yaml", ".toml", ".ini", ".cfg", ".json")):
            return 2
        if lp.startswith(("utils/", "src/", "app/", "lib/", "api/")):
            return 3
        if lp.endswith(".py"):
            return 4
        return 10
    ranked = sorted(all_files, key=lambda p: (score(p), p))
    return ranked[:max_files]


def execute_plan(state: AgentState) -> AgentState:
    """Execute the plan by calling tools."""
    print("EXECUTOR: executing plan")

    listed_files: List[str] = []
    list_files_succeeded = False
    global_failures = [0]  # mutable counter

    task_files = _extract_task_files(state.task)
    task_lines = _extract_task_line_numbers(state.task)

    for step in state.plan:
        print(f" - {step}")

        if step == "List repository files":
            print("   -> Calling list_files tool")
            try:
                result = lf_mod.list_files(state.repo_path)
                state.tool_calls.append({
                    "tool": "list_files",
                    "name": "list_files",
                    "repo_path": state.repo_path,
                    "returned_file_count": len(result.files),
                    "ignored_dir_count": result.ignored_count,
                    "result_status": "success",
                })
                state.retrieved_files.append({
                    "tool": "list_files",
                    "repo_path": state.repo_path,
                    "files": result.files,
                    "total_files": len(result.files),
                })
                listed_files = result.files
                list_files_succeeded = True
                print(f"   -> Found {len(result.files)} files (ignored dirs: {result.ignored_count})")

            except Exception as e:
                print(f"   !! list_files failed: {e}")
                state.tool_calls.append({
                    "tool": "list_files",
                    "name": "list_files",
                    "repo_path": state.repo_path,
                    "returned_file_count": 0,
                    "ignored_dir_count": 0,
                    "error": f"{type(e).__name__}: {e}",
                    "result_status": "error",
                })

        elif step == "Read relevant files":
            # Empty repo (list_files succeeded with 0 files) — skip
            if list_files_succeeded and not listed_files:
                print("   !! No file list available. Skipping read_file.")
                continue

            # list_files failed — try task-mentioned files or defaults
            if not listed_files and task_files:
                to_read = task_files
                print(f"   -> No file list; trying {len(to_read)} file(s) from task")
            elif not listed_files:
                to_read = ["main.py"]
                print("   -> No file list; trying default files")
            else:
                to_read = _pick_files_to_read(listed_files, max_files=6)
                print(f"   -> Reading {len(to_read)} files")

            for rel_path in to_read:
                if global_failures[0] >= MAX_GLOBAL_RETRIES:
                    print(f"     !! Global retry budget exhausted ({MAX_GLOBAL_RETRIES})")
                    break

                # Normalize path
                rel_path = os.path.normpath(rel_path)

                _read_with_retries(state, rel_path, global_failures, task_lines)

    return state


def _read_with_retries(
    state: AgentState,
    rel_path: str,
    global_failures: List[int],
    task_lines: List[Tuple[int, int]],
) -> None:
    """Read a file with retries. Tracks global failure budget."""

    # Check if task mentions specific lines for this file
    line_start = None
    line_end = None
    if len(task_lines) == 1 and task_lines[0][0] > 200:
        # Task asks for a specific high line — pass line range to tool
        ls, le = task_lines[0]
        line_start = max(1, ls - 5)
        line_end = le + 5

    max_lines = 5000

    for attempt in range(1, MAX_FILE_RETRIES + 1):
        if global_failures[0] >= MAX_GLOBAL_RETRIES:
            break

        try:
            if line_start is not None:
                res = rf_mod.read_file(state.repo_path, rel_path,
                                       line_start=line_start, line_end=line_end)
            else:
                try:
                    res = rf_mod.read_file(state.repo_path, rel_path, max_lines=max_lines)
                except TypeError:
                    res = rf_mod.read_file(state.repo_path, rel_path)

            # Success — record it
            state.tool_calls.append({
                "tool": "read_file",
                "name": "read_file",
                "repo_path": state.repo_path,
                "path": rel_path,
                "returned_lines": len(getattr(res, "lines", []) or []),
                "truncated": bool(getattr(res, "truncated", False)),
                "is_binary": bool(getattr(res, "is_binary", False)),
                "error": getattr(res, "error", None),
                "attempt": attempt,
                "result_status": "success",
            })
            state.retrieved_files.append({
                "tool": "read_file",
                "repo_path": state.repo_path,
                "path": getattr(res, "path", rel_path),
                "lines": getattr(res, "lines", []) or [],
                "total_lines": int(getattr(res, "total_lines", 0) or 0),
                "truncated": bool(getattr(res, "truncated", False)),
                "is_binary": bool(getattr(res, "is_binary", False)),
                "error": getattr(res, "error", None),
            })
            lines_read = len(getattr(res, "lines", []) or [])
            is_bin = bool(getattr(res, "is_binary", False))
            print(f"     -> Read {rel_path} ({lines_read} lines, "
                  f"truncated={bool(getattr(res, 'truncated', False))})"
                  + (" [BINARY/UNSUPPORTED]" if is_bin else ""))
            return

        except Exception as e:
            global_failures[0] += 1
            state.tool_calls.append({
                "tool": "read_file",
                "name": "read_file",
                "repo_path": state.repo_path,
                "path": rel_path,
                "returned_lines": 0,
                "error": f"{type(e).__name__}: {e}",
                "attempt": attempt,
                "result_status": "error",
            })
            if attempt < MAX_FILE_RETRIES:
                print(f"     !! Read failed ({attempt}/{MAX_FILE_RETRIES}) for {rel_path}: "
                      f"{type(e).__name__}: {e}")
            else:
                print(f"     !! Skipped {rel_path} after {MAX_FILE_RETRIES} attempts: "
                      f"{type(e).__name__}: {e}")

    # All attempts failed — record in retrieved_files
    state.retrieved_files.append({
        "tool": "read_file",
        "repo_path": state.repo_path,
        "path": rel_path,
        "lines": [],
        "total_lines": 0,
        "is_binary": False,
        "error": "All read attempts failed",
    })