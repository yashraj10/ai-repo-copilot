"""
Verifier node — validates schema and citations, sets validation feedback for retries.
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, List

from eval.schema_validate import validate_output_schema
from eval.citation_validate import validate_citations
from agent.state import AgentState


def _task_targets_file(task: str, filename: str) -> bool:
    """Check if the task specifically asks about a given file."""
    task_lower = task.lower()
    fname_lower = filename.lower()
    basename = os.path.basename(fname_lower)
    return fname_lower in task_lower or basename in task_lower


def _is_path_traversal_task(task: str) -> bool:
    """Detect if the task references paths outside the repository."""
    patterns = [r'\.\./\.\.', r'/etc/', r'/usr/', r'/var/', r'/tmp/', r'/home/', r'\\windows\\']
    return any(re.search(pat, task.lower()) for pat in patterns)


def verify_output(state: AgentState) -> AgentState:
    """Validate the agent's output and build retry feedback."""
    print("VERIFIER: checking rules")

    # Schema validation
    schema_ok, schema_errs = validate_output_schema(state.output)
    state.schema_valid = schema_ok
    state.schema_errors = schema_errs

    # Citation validation
    citations_ok, citation_errs = validate_citations(
        output=state.output,
        retrieved_files=state.retrieved_files,
        repo_path=state.repo_path,
    )
    state.citations_valid = citations_ok
    state.citation_errors = citation_errs

    # Additional invalidation rules
    has_citations = (
        isinstance(state.output, dict)
        and isinstance(state.output.get("high_risk_areas"), list)
        and len(state.output.get("high_risk_areas", [])) > 0
    )

    # Check binary files targeted by task
    binary_files = [
        x.get("path", "")
        for x in (state.retrieved_files or [])
        if x.get("tool") == "read_file" and x.get("is_binary")
    ]
    for bf in binary_files:
        if _task_targets_file(state.task, bf):
            if state.citations_valid:
                state.citations_valid = False
                state.citation_errors.append(
                    f"Task targets binary file '{bf}'; citations cannot be validated."
                )

    # Check security errors in evidence
    if has_citations:
        for x in (state.retrieved_files or []):
            if x.get("tool") != "read_file":
                continue
            err = x.get("error", "") or ""
            if any(kw in err.lower() for kw in ["symlink", "path traversal", "escapes repo"]):
                if state.citations_valid:
                    state.citations_valid = False
                    state.citation_errors.append(
                        f"Security error for '{x.get('path', 'unknown')}': {err}"
                    )

    # Check path traversal in task (even with no citations)
    if _is_path_traversal_task(state.task):
        if state.citations_valid:
            state.citations_valid = False
            state.citation_errors.append(
                "Task references paths outside repository; citations cannot be validated."
            )

    # Build retry feedback for LangGraph retry loop
    if not state.schema_valid or not state.citations_valid:
        feedback_parts = []
        if not state.schema_valid:
            feedback_parts.append("SCHEMA ERRORS: " + "; ".join(state.schema_errors))
        if not state.citations_valid:
            feedback_parts.append("CITATION ERRORS: " + "; ".join(state.citation_errors))
        state.last_validation_feedback = "\n".join(feedback_parts)
    else:
        state.last_validation_feedback = None

    # Print results
    if state.schema_valid:
        print("   OK: Output matches JSON schema.")
    else:
        print("   FAIL: Schema validation failed.")
        for err in state.schema_errors:
            print(f"      - {err}")

    if state.citations_valid:
        print("   OK: Citations reference read files and valid line ranges.")
    else:
        print("   FAIL: Citation validation failed.")
        for err in state.citation_errors:
            print(f"      - {err}")

    return state