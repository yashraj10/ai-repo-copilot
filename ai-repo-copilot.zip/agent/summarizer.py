"""
Summarizer node — calls the LLM to generate structured output.

Handles:
- First-pass generation from evidence
- Retry with validation feedback (LangGraph retry loop)
- Context notes from analyzer
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

from langchain_openai import ChatOpenAI


LINE_PREFIX_RE = re.compile(r"^\s*(\d+)\|\s*(.*)$")


def _evidence_blob(retrieved_files: List[Dict[str, Any]], max_chars: int = 12000) -> str:
    """Build evidence blob from retrieved files."""
    parts: List[str] = []
    for item in retrieved_files:
        if item.get("tool") != "read_file":
            continue
        if item.get("is_binary") or item.get("error"):
            continue
        path = item.get("path", "")
        lines = item.get("lines", []) or []
        if lines:
            parts.append(f"FILE: {path}\n" + "\n".join(lines))
    blob = "\n\n".join(parts)
    return blob[:max_chars] + ("\n\n[TRUNCATED]" if len(blob) > max_chars else "")


def _clean_to_schema(output: Any) -> Dict[str, Any]:
    """
    Hard schema clamp: only allow the 3 required fields.
    Does NOT auto-fill missing fields — lets the validator catch errors.
    """
    if not isinstance(output, dict):
        return {"summary": "Invalid output type", "high_risk_areas": [], "confidence": "low"}

    summary = output.get("summary")
    confidence = output.get("confidence")
    hra = output.get("high_risk_areas")

    if not isinstance(summary, str):
        summary = "Cannot analyze reliably."
    if confidence not in ("low", "medium", "high"):
        confidence = "low"
    if not isinstance(hra, list):
        hra = []

    # Clean high_risk_areas items — strict 4 fields only
    cleaned_hra: List[Dict[str, Any]] = []
    for item in hra:
        if not isinstance(item, dict):
            continue
        fp = item.get("file_path")
        ls = item.get("line_start")
        le = item.get("line_end")
        desc = item.get("description")

        if not isinstance(fp, str) or not fp.strip():
            continue
        if not isinstance(desc, str) or not desc.strip():
            continue
        if not isinstance(ls, int) or not isinstance(le, int):
            continue

        cleaned_hra.append({
            "file_path": fp.strip(),
            "line_start": ls,
            "line_end": le,
            "description": desc.strip(),
        })

    return {
        "summary": summary.strip(),
        "high_risk_areas": cleaned_hra,
        "confidence": confidence,
    }


def _get_context_notes(state_output: Dict[str, Any]) -> List[str]:
    """Extract context notes left by the analyzer."""
    notes = state_output.get("_context_notes", [])
    return notes if isinstance(notes, list) else []


def _build_prompt(
    task: str,
    evidence: str,
    context_notes: List[str],
    retry_feedback: Optional[str] = None,
) -> str:
    """Build the LLM prompt."""

    notes_section = ""
    if context_notes:
        notes_section = "\n\nCONTEXT NOTES:\n" + "\n".join(f"- {n}" for n in context_notes)

    retry_section = ""
    if retry_feedback:
        retry_section = f"""

PREVIOUS ATTEMPT FAILED VALIDATION:
{retry_feedback}
Please fix the issues above. Make sure your output strictly matches the schema.
"""

    return f"""Output JSON only. No markdown. No extra text. No code fences.

Task:
{task}
{notes_section}
Evidence (line-numbered excerpts):
{evidence}

Return JSON with EXACTLY this shape (no extra keys, no nested arrays):
{{
  "summary": "string",
  "high_risk_areas": [
    {{
      "file_path": "string",
      "line_start": 1,
      "line_end": 5,
      "description": "string"
    }}
  ],
  "confidence": "low|medium|high"
}}

CRITICAL RULES:
1. Use ONLY the Evidence above. Do not invent files or code.
2. line_start/line_end MUST be integers from the evidence line numbers.
3. Each high_risk_areas item MUST have EXACTLY 4 fields: file_path, line_start, line_end, description.
4. NO extra fields anywhere in the JSON.
5. If evidence shows something the task asks about doesn't exist, say so clearly in summary with empty high_risk_areas.
6. If a file mentioned in the task is listed as "not found" in context notes, mention that in the summary.
7. If the task claims something exists but evidence doesn't show it, say "No [claimed thing] found" in summary.
8. When the task asks to cite from multiple specific files, provide exactly one citation per file.
9. Do NOT blindly trust line numbers from the task — verify against evidence.
10. file_path values must EXACTLY match the FILE: headers in the evidence.
{retry_section}""".strip()


def generate_structured_summary(
    task: str,
    retrieved_files: List[Dict[str, Any]],
    context_notes: Optional[List[str]] = None,
    retry_feedback: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate structured summary from task and retrieved files.
    
    Args:
        task: The analysis task
        retrieved_files: Evidence from the executor
        context_notes: Notes from the analyzer about missing files, binary, etc.
        retry_feedback: Validation errors from previous attempt (retry loop)
    """

    evidence = _evidence_blob(retrieved_files)

    if not evidence.strip():
        return {"summary": "No readable evidence found.", "high_risk_areas": [], "confidence": "low"}

    prompt = _build_prompt(
        task=task,
        evidence=evidence,
        context_notes=context_notes or [],
        retry_feedback=retry_feedback,
    )

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    try:
        msg = llm.invoke(prompt)
        raw = (msg.content or "").strip()

        # Remove markdown fences if present
        if raw.startswith("```"):
            lines = raw.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            raw = "\n".join(lines)

        parsed = json.loads(raw)
        return _clean_to_schema(parsed)

    except Exception as e:
        return {
            "summary": "Cannot analyze reliably due to JSON parsing failure.",
            "high_risk_areas": [],
            "confidence": "low",
        }