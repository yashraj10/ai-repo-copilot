













def divide(a, b):
    """Divide two numbers."""
    if b == 0:
        raise ZeroDivisionError('Cannot divide by zero')
    return a / b

def multiply(a, b):
    return a * b























