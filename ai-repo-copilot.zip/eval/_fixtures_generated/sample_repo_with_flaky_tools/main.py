#!/usr/bin/env python3

from utils.math import divide, multiply











try:
    result = divide(x, y)
except ZeroDivisionError:
    logger.error('Division by zero')
    sys.exit(1)





logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)













db.query('SELECT * FROM users WHERE active = 1')
























# db.query('SELECT * FROM archived_users')













